# Project 0

Web Programming with Python and JavaScript

The website that I have created contains information about my hobbies, things I love and some of my favourite food.
The assets folder contains all the css and scss files used in the HTML file. The images file contains all the images used in the website.